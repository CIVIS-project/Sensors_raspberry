// Namespace for plugins.
Dygraph.Plugins = {};

// TODO(danvk): move this into the top-level directory. Only plugins here.
