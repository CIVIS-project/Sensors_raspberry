sudo mkdir /var/www/ecpiww


sudo cp www/index.html /var/www/index.html
sudo cp -avr www/ecpiww/ /var/www

